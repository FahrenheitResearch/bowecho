# Integration Guide

## Reviewed upstream revision

The source transformer is pinned to:

```text
tsupinie/autumnplot-gl
ee93a7278c0f38026ea61d2ce2c1d6a21893d723
```

The installer refuses another commit unless `--force` is supplied. `--force` bypasses only the commit check; all source anchors are still required.

## Clean application

```bash
git clone https://github.com/tsupinie/autumnplot-gl.git
cd autumnplot-gl
git checkout ee93a7278c0f38026ea61d2ce2c1d6a21893d723
node /path/to/package/integration/apply-current-upstream.mjs "$PWD"
```

The command creates `.autumnplot-weather-contours-backup/` containing the original `Fill.ts`, `index.ts`, `ContourCreator.worker.ts`, and HEAD before writing changes.

It then:

1. Copies `WeatherContours.ts` and `WeatherContoursWasm.ts` into `src/`.
2. Replaces `src/ContourCreator.worker.ts` with an API-compatible Rust/OIRT worker.
3. Copies the three WebGL 2 shaders into `src/glsl/`.
4. Copies the dependency-free Rust crate into `rust/weather-contours/`.
5. Extends `ContourFillOptions` with line options and defaults.
6. Replaces the old `ContourFill` class body with a subclass of `WeatherContours`.
7. Adds public exports for the GPU component, option types, auto-tune cache control, WASM loader, and packed result types.

The transformation is idempotent. Any anchor failure restores tracked files and removes copied integration files.

## Build

```bash
npm ci
npm run build-npm
npm run build-dist
./rust/weather-contours/build-wasm.sh "$PWD/lib" "$PWD/dist" "$PWD/public"
```

The Rust command is a locked release build for `wasm32-unknown-unknown` and copies the same module to:

```text
lib/weather_contours.wasm     # npm library / worker-relative load
dist/weather_contours.wasm    # production UMD bundle deployment
public/weather_contours.wasm  # webpack development server
```

With no explicit destinations, the script writes to every one of those directories that already exists.

Requirements:

- Rust 1.89.0 with `wasm32-unknown-unknown`;
- the existing AutumnPlot npm/webpack requirements;
- WebGL 2 at runtime for `ContourFill` after this integration. Float32 linear filtering is optional because the shader has a four-tap fallback.

No `wasm-pack` or `wasm-bindgen` command is involved.

## Existing fill call sites

Basic calls remain valid:

```ts
const fill = new ContourFill(field, {cmap, opacity: 0.8});
```

Enable GPU boundaries without adding a separate vector `Contour` layer:

```ts
const fill = new ContourFill(field, {
    cmap,
    opacity: 0.88,
    lines: true,
    line_mode: 'auto',
    line_width: 0.9,
    major_every: 5,
    major_line_width: 1.8,
});
```

Inspect the runtime decision:

```ts
console.log(fill.renderer);
console.log(fill.resolvedLineMode);
console.log(fill.isAutoTuning);
console.log(fill.maximumDirectorySpan);
console.log(fill.usesManualBilinearFiltering);
```

Clear cached renderer decisions before profiling:

```ts
clearWeatherContourAutoTuneCache();
```


## Existing vector contour and label call sites

No call-site rewrite is required:

```ts
const contour = new Contour(field, {interval: 4});
const labels = new ContourLabels(contour, {halo: true});
```

`RawScalarField.getContours()`, `Contour`, and `ContourLabels` now reach Rust OIRT through the replaced worker. The worker preserves the old `ContourData` return shape, including a duplicated first point for closed paths. `quad_as_tri` is accepted but ignored with a one-time warning because ambiguous cells always use the bilinear asymptotic decider. A practical 65,536-level guard prevents accidental multi-gigabyte compatibility allocations.

This compatibility lane still pays AutumnPlot's existing per-point grid transform and nested-array construction after Rust returns. For export, picking, large batch analysis, or a new renderer, use `WeatherContoursWasm.contourLevels()` directly and keep the packed arrays.

The integration deliberately does not delete the old generated C++ files from the repository. They are no longer referenced by `ContourCreator.worker.ts`; removing the unused shipping artifacts can be a separate cleanup after downstream package compatibility is verified.

## True geometry through WASM

```ts
const geometry = await loadWeatherContoursWasm('/dist/weather_contours.wasm');

const lines = geometry.contourLevels(
    values,
    nx,
    ny,
    xCoordinates,
    yCoordinates,
    levels,
);

const bands = geometry.isobands(
    values,
    nx,
    ny,
    xCoordinates,
    yCoordinates,
    levels,
);
```

`lines.pathOffsets` is measured in points, not float elements. A closed path is indicated by the low bit of the corresponding `pathFlags` entry and does not repeat its first point.

`bands.indices` is a u32 triangle list. `triangleBandIndices[t]` identifies the interval `[levels[k], levels[k+1]]` for triangle `t`.

Coordinates are emitted in the supplied structured-grid X/Y coordinate system. Conversion to longitude/latitude, projected coordinates, GeoJSON, or application-specific objects belongs after packed extraction and can be batched by the caller.

## Selectable upstream demo

```bash
node /path/to/package/demo/install-current-upstream-demo.mjs "$PWD"
npm run start
```

Select **WeatherContours SOTA**. The installer modifies only `public/main.js` and saves the exact original as `.autumnplot-weather-contours-demo-main.js`.

Revert the demo with:

```bash
node /path/to/package/demo/revert-current-upstream-demo.mjs "$PWD"
```

## Revert the library integration

```bash
node /path/to/package/integration/revert.mjs "$PWD"
```

This restores `src/Fill.ts`, `src/index.ts`, and `src/ContourCreator.worker.ts`, removes copied TypeScript/shader/Rust files, and deletes the integration backup. Generated `weather_contours.wasm` copies are build outputs and are not removed automatically.

Revert the demo first if both were installed.

## Rebase checklist for a future AutumnPlot commit

Do not use `--force` and assume success. Review at least:

1. `Fill.ts` constructor, options, shader setup, mask behavior, world-copy draws, and public exports.
2. `RawField.ts` contour cache, per-point transform, texture formats, and sampler-expression injection.
3. `ContourCreator.worker.ts`, Comlink transfer behavior, and worker-relative WASM deployment.
4. `ShaderManager.ts` and AutumnWGL uniform/preprocessor behavior.
5. MapLibre/Mapbox renderer-data variants, including globe projection.
6. `ColorMap` boundary semantics, underflow/overflow behavior, and alpha handling.
7. WebGL 1 support expectations, because this implementation deliberately requires WebGL 2.
8. Public demo anchors.
9. The full CI matrix, real shader compilation, and physical-GPU benchmark.

After adapting anchors, change the pinned SHA in the installer, demo installer, CI workflow, and documentation together.
