# AutumnPlot Weather Contours SOTA Candidate

A full rewrite of AutumnPlot's weather-contour path, built against **autumnplot-gl commit `ee93a7278c0f38026ea61d2ce2c1d6a21893d723`**.

This version fixes the main defect in the first prototype: it is a real filled-contour system, not merely a fast isoline renderer.

## What is included

### 1. Exact GPU `contourf` display

`WeatherContours` classifies every finite scalar sample into an exact discrete color band on the GPU and can draw antialiased boundary isolines in the same component.

- Correct filled bands, including transparent or colored underflow and overflow.
- Regular and arbitrary nonlinear level arrays.
- Up to 4096 float32 boundaries.
- Float16 and float32 source fields through AutumnPlot's existing sampler-expression path.
- Automatic four-tap manual bilinear fallback when a WebGL 2 device lacks float32 linear filtering.
- Computed scalar fields without CPU materialization.
- Multiple color maps selected by the existing 1-based `cmap_mask` convention.
- Optional minor and major screen-space isolines.
- Fused one-pass fill-plus-lines or specialized two-pass rendering.
- `auto` mode measures both variants with `EXT_disjoint_timer_query_webgl2`, caches the faster choice for the renderer/configuration, and safely defaults to fused when timer queries are unavailable.

The integration makes the existing `ContourFill` class inherit this implementation, so existing fill call sites keep their basic API:

```ts
const fill = new ContourFill(field, {
    cmap,
    opacity: 0.9,
    lines: true,
    line_mode: 'auto',
    line_width: 1,
    major_every: 5,
    major_line_width: 2,
});
```

A separately exported `WeatherContours` class provides the same implementation without hiding the architectural change.

### 2. Rust connected isolines: OIRT

**Ordinal Iso-Rail Traversal (OIRT)** generates actual connected vector paths for labels, export, picking, path-continuous dashes, and analysis.

Instead of hashing interpolated floating-point endpoints, OIRT assigns an exact integer identity to every `(grid edge, level ordinal)` crossing. Cells connect those IDs directly into a graph whose contour nodes have degree at most two. Open chains are traversed first; remaining components are cycles.

The output is packed typed-array data:

- flat XY vertices;
- path offsets;
- path level ordinals;
- explicit closed-path flags;
- extraction statistics.

The pinned integration also replaces AutumnPlot's existing `ContourCreator.worker.ts`. As a result, `RawScalarField.getContours()`, `Contour`, and `ContourLabels` keep their public API but extract topology through Rust OIRT instead of the old C++ marching-squares worker. The compatibility worker widens all binary16 inputs through a complete lookup table, converts packed paths back to `ContourData`, and duplicates the first point only for closed paths because the old shape has no closure flag. Direct `WeatherContoursWasm` callers retain the smaller packed representation and avoid that compatibility object graph.

### 3. Rust filled geometry: COBRM

**Critical Ordinal Band-Rail Mesh (COBRM)** produces indexed interior isoband triangles when actual filled geometry is required.

Each finite bilinear cell is decomposed into a four-triangle fan. For a genuine interior saddle, the fan center is the exact bilinear critical point; otherwise it is the bilinear center. Triangle-band clipping then emits indexed geometry. Shared crossings are keyed by integer grid/spoke rails plus level ordinal, avoiding floating-point endpoint keys.

This gives topology-consistent vector bands across ambiguous saddle cells. The emitted boundary geometry is a piecewise-linear approximation to the bilinear contour, not a claim of exact curved-hyperbola geometry.

### 4. Dependency-free raw WASM ABI

The Rust crate builds directly with Cargo:

```bash
./rust/weather-contours/build-wasm.sh
```

It does **not** require `wasm-pack`, `wasm-bindgen`, JavaScript glue generation, or third-party Rust dependencies. `WeatherContoursWasm.ts` handles allocation, input upload, packed-output copying, and handle cleanup. With no arguments, the build script copies `weather_contours.wasm` into whichever of `dist/`, `lib/`, and `public/` already exist; explicit output directories may also be supplied. This places the module beside the bundled worker, npm-library worker, and development-server worker respectively.

The allocator ABI uses boxed slices, so JavaScript returns the exact allocation length rather than guessing a `Vec` capacity.

## Why the GPU classifier is exact

The previous AutumnPlot fill path uses a 101-entry nonlinear lookup texture to approximate the inverse mapping from value to color ordinal. This package uses direct ordinal classification.

For exactly representable regular maps, an arithmetic estimate is checked against its reconstructed lower and upper float32 boundaries. The common one-bin rounding slip is repaired, and an exact bounded search remains as a defensive cold fallback. This matters at values such as the float immediately below zero, where subtraction can round across a boundary.

For arbitrary levels, an **Exact Ordinal Directory (EOD)** maps each normalized value bucket to a conservative upper-bound search interval. The shader then performs a fixed 13-step binary search, sufficient for the complete half-open interval of 4096 boundaries. Directory construction expands bucket coverage around float32 bin edges so the bracket remains conservative under shader rounding.

Color maps whose complete numeric span cannot be represented as a finite positive float32 value are rejected rather than classified with an overflowed normalization denominator.

## Performance result included in the package

The reproducible browser microbenchmark uses a 1799×1059 scalar texture, a 1024×768 viewport, 17 boundaries, seven rounds, and 12 frames per round. On Chromium WebGL 2 through SwiftShader in this environment:

| Path | Median GPU time |
|---|---:|
| Current-shape GPU fill baseline | 27.293 ms |
| Exact GPU fill | 22.841 ms |
| Favorable legacy GPU-only fill + analytic lines | 41.965 ms |
| Exact split fill + lines | 54.159 ms |
| Exact fused fill + lines | 36.517 ms |

That is **1.19× fill throughput** and **1.15× fused fill-plus-line throughput** against the stated baselines in this software-rendered run. The split variant lost here, which is why `auto` measures rather than assumes.

These are not physical-GPU claims. The favorable legacy line baseline also omits the current worker/WASM extraction, topology joining, coordinate transformation, JavaScript object creation, and polyline upload costs. Re-run `python3 bench/webgl_benchmark.py` on every hardware class before publishing device-specific numbers.

## Validation completed here

```text
TypeScript strict integration check passed (tsc 5.8.3)
Exact GPU classifier validation passed
  - 4096-boundary maximum
  - clustered and logarithmic maps
  - maximum tested EOD bracket: 3382
  - 301,649 adversarial regular-level probes
  - zero defensive cold fallbacks in those regular probes
  - 100,000 fused/split alpha-equivalence cases
COBRM reference validation passed
  - 25,000 full-coverage cells
  - 8,380 interior saddles
  - maximum area error 4.441e-16
  - 5,000 partial-coverage cells
OIRT compatibility-worker reference validation passed
  - all 65,536 binary16 patterns
  - 20,000 interval-generation cases
  - 75,703 packed open/closed paths
Rust structural/ABI validation passed
  - 3 Rust modules
  - 29 TypeScript loader exports matched
Pinned integration apply/idempotence/revert passed
Pinned public-demo install/idempotence/revert passed
Real Chromium WebGL2 compile/link passed
  - 36 shader variants, including hardware and manual-bilinear sampling
  - native GLSL preprocessing and AutumnWGL-style preprocessing
  - 72 compile/link/uniform-activity paths total
```

A Rust toolchain was not present in the artifact environment, and outbound toolchain download was unavailable. Therefore this package does **not** falsely claim a local `cargo test`, Clippy, native benchmark, or generated WASM pass. The included CI workflow pins Rust 1.89.0 and requires formatting, Clippy with warnings denied, native tests, example compilation, raw WASM compilation, and a build against the pinned AutumnPlot checkout.

## Apply to the pinned AutumnPlot checkout

```bash
git clone https://github.com/tsupinie/autumnplot-gl.git
cd autumnplot-gl
git checkout ee93a7278c0f38026ea61d2ce2c1d6a21893d723

node /path/to/autumnplot-weather-contours-sota/integration/apply-current-upstream.mjs "$PWD"
npm ci
npm run build-npm
npm run build-dist
./rust/weather-contours/build-wasm.sh "$PWD/lib" "$PWD/dist" "$PWD/public"
```

The installer:

- checks the exact reviewed commit unless `--force` is supplied;
- creates a backup before modifying tracked files;
- copies the TypeScript, shaders, loader, and Rust crate;
- rewrites `ContourFill` through anchored source transformations;
- replaces the existing contour worker so `Contour` and `ContourLabels` use OIRT;
- exports the new GPU and WASM APIs;
- is idempotent;
- rolls back on an integration-anchor failure.

Revert the library integration with:

```bash
node /path/to/autumnplot-weather-contours-sota/integration/revert.mjs "$PWD"
```

## Run the real AutumnPlot map demo

```bash
node /path/to/autumnplot-weather-contours-sota/demo/install-current-upstream-demo.mjs "$PWD"
npm run start
```

Choose **WeatherContours SOTA** from AutumnPlot's existing selector. The demo uses AutumnPlot's own grid, field, color-map, custom-layer, and MapLibre path. Its on-map panel reports map frame interval p50/p95, JavaScript render-submission p50/p95, texture-upload p50/p95, renderer, EOD bracket size, and auto-selected line mode while rotating through 12 precomputed weather-like fields.

## API boundaries

The execution lanes are intentionally distinct:

| Need | Use |
|---|---|
| Interactive filled weather display | `ContourFill` / `WeatherContours` GPU path |
| Interactive solid boundary lines | `WeatherContours({lines: true})` |
| Existing AutumnPlot vector lines and labels | `Contour` / `ContourLabels`, now backed by the OIRT worker |
| Picking, GeoJSON, batched path analysis, custom dashes | Direct packed Rust/WASM OIRT output |
| Exportable filled polygons/triangles | Rust/WASM COBRM isobands |

The GPU path does not pretend to produce connected geometry. OIRT does not pretend to fill bands. COBRM currently emits only bounded interior bands `[levels[k], levels[k+1]]`; unbounded underflow/overflow remain a display concept unless a caller supplies an explicit clipping domain and finite outer levels.

## Compatibility and deliberate breaking points

- Exact GPU filled contours require **WebGL 2**. This is stricter than retaining a WebGL 1 fallback. Float32 textures use hardware linear filtering when available and an automatic four-sample shader fallback otherwise.
- The current `DomainBufferGrid` compatibility envelope is preserved; unstructured-grid fill is not added.
- GPU lines are solid, screen-space lines. Path-continuous dash phase, labels, and picking require OIRT geometry.
- Existing `Contour` compatibility still converts packed paths to nested JavaScript arrays and then lets `RawField` transform each point. Use the direct packed loader when that conversion is unnecessary.
- `quad_as_tri` remains accepted for source compatibility but is ignored with a one-time warning; OIRT always uses bilinear asymptotic saddle topology.
- Level arrays are converted to float32 and must remain finite and strictly increasing after conversion.
- A GPU color map may contain at most 4096 boundaries; the compatibility vector worker rejects more than 65,536 requested levels before allocation.
- The current integration is pinned, not a promise that source anchors will survive an unreviewed future upstream commit.

## Package map

```text
autumnplot-src/WeatherContours.ts          exact GPU contourf + optional isolines
autumnplot-src/WeatherContoursWasm.ts      raw WASM loader and packed outputs
autumnplot-src/ContourCreator.worker.ts     drop-in OIRT worker for Contour/labels
autumnplot-src/glsl/                       production WebGL 2 shaders
rust/weather-contours/src/lib.rs            OIRT connected isolines
rust/weather-contours/src/bands.rs          COBRM indexed interior isobands
rust/weather-contours/src/wasm_abi.rs       dependency-free C-style WASM ABI
integration/                                pinned apply/revert scripts
demo/                                       selectable upstream map demo
validation/                                 deterministic, shader, and integration gates
bench/                                      reproducible WebGL benchmark and results
.github/workflows/validate.yml              Rust/WASM/upstream build gates
```

See [DESIGN.md](DESIGN.md), [INTEGRATION.md](INTEGRATION.md), [VALIDATION.md](VALIDATION.md), and [REVIEW-RESPONSE.md](REVIEW-RESPONSE.md) for the detailed engineering record.

## Novelty statement

The names OIRT, EOD, and COBRM and these specific implementations were developed for this rewrite. They combine established ideas—marching methods, asymptotic saddle disambiguation, prefix-assigned crossing identities, interval directories, and polygon clipping—in a weather-grid-specific architecture. No formal exhaustive prior-art or patent search was performed, so the package does not claim publication-level or legally established novelty.
