/** Packed connected isolines returned by the dependency-free Rust/WASM ABI. */
export interface WasmPackedContours {
    levels: Float32Array;
    vertices: Float32Array;
    pathOffsets: Uint32Array;
    pathLevelIndices: Uint32Array;
    pathFlags: Uint8Array;
    stats: Uint32Array;
}

/** Packed indexed interior isobands returned by COBRM. */
export interface WasmPackedBands {
    levels: Float32Array;
    vertices: Float32Array;
    indices: Uint32Array;
    triangleBandIndices: Uint32Array;
    stats: Uint32Array;
}

type NumericExport = (...args: number[]) => number;

interface WeatherContoursExports extends WebAssembly.Exports {
    memory: WebAssembly.Memory;
    wc_last_error: NumericExport;
    wc_alloc_f32: NumericExport;
    wc_free_f32: NumericExport;
    wc_contour_levels: NumericExport;
    wc_isobands: NumericExport;
    wc_lines_free: NumericExport;
    wc_bands_free: NumericExport;
    wc_lines_levels_ptr: NumericExport;
    wc_lines_levels_len: NumericExport;
    wc_lines_vertices_ptr: NumericExport;
    wc_lines_vertices_len: NumericExport;
    wc_lines_path_offsets_ptr: NumericExport;
    wc_lines_path_offsets_len: NumericExport;
    wc_lines_path_levels_ptr: NumericExport;
    wc_lines_path_levels_len: NumericExport;
    wc_lines_path_flags_ptr: NumericExport;
    wc_lines_path_flags_len: NumericExport;
    wc_lines_stats_ptr: NumericExport;
    wc_lines_stats_len: NumericExport;
    wc_bands_levels_ptr: NumericExport;
    wc_bands_levels_len: NumericExport;
    wc_bands_vertices_ptr: NumericExport;
    wc_bands_vertices_len: NumericExport;
    wc_bands_indices_ptr: NumericExport;
    wc_bands_indices_len: NumericExport;
    wc_bands_triangle_bands_ptr: NumericExport;
    wc_bands_triangle_bands_len: NumericExport;
    wc_bands_stats_ptr: NumericExport;
    wc_bands_stats_len: NumericExport;
}

export type WeatherContoursWasmSource =
    | string
    | URL
    | ArrayBuffer
    | WebAssembly.Module
    | Response;

interface InputBuffer {
    pointer: number;
    length: number;
    values: Float32Array;
}

export class WeatherContoursWasm {
    public constructor(private readonly exports: WeatherContoursExports) {}

    private allocate(values: Float32Array | readonly number[]): InputBuffer {
        const normalized = values instanceof Float32Array ? values : new Float32Array(values);
        const pointer = this.exports.wc_alloc_f32(normalized.length);
        if (normalized.length > 0 && pointer === 0) {
            throw new Error('Rust/WASM input allocation failed.');
        }
        return {pointer, length: normalized.length, values: normalized};
    }

    private upload(buffers: readonly InputBuffer[]): void {
        // Allocate everything first: a later Rust allocation may grow memory and
        // detach an earlier JavaScript view.
        const memory = this.exports.memory.buffer;
        for (const buffer of buffers) {
            if (buffer.length > 0) {
                new Float32Array(memory, buffer.pointer, buffer.length).set(buffer.values);
            }
        }
    }

    private release(buffers: readonly InputBuffer[]): void {
        for (const buffer of buffers) {
            this.exports.wc_free_f32(buffer.pointer, buffer.length);
        }
    }

    private copyF32(pointer: number, length: number): Float32Array {
        if (length === 0) return new Float32Array();
        return new Float32Array(
            new Float32Array(this.exports.memory.buffer, pointer, length),
        );
    }

    private copyU32(pointer: number, length: number): Uint32Array {
        if (length === 0) return new Uint32Array();
        return new Uint32Array(
            new Uint32Array(this.exports.memory.buffer, pointer, length),
        );
    }

    private copyU8(pointer: number, length: number): Uint8Array {
        if (length === 0) return new Uint8Array();
        return new Uint8Array(
            new Uint8Array(this.exports.memory.buffer, pointer, length),
        );
    }

    private throwLastError(operation: string): never {
        throw new Error(`${operation} failed in Rust/WASM (error code ${this.exports.wc_last_error()}).`);
    }

    public contourLevels(
        values: Float32Array,
        nx: number,
        ny: number,
        xs: Float32Array | readonly number[],
        ys: Float32Array | readonly number[],
        levels: Float32Array | readonly number[],
    ): WasmPackedContours {
        const inputs = [
            this.allocate(values),
            this.allocate(xs),
            this.allocate(ys),
            this.allocate(levels),
        ];
        this.upload(inputs);
        let handle = 0;
        try {
            handle = this.exports.wc_contour_levels(
                inputs[0].pointer,
                inputs[0].length,
                nx,
                ny,
                inputs[1].pointer,
                inputs[1].length,
                inputs[2].pointer,
                inputs[2].length,
                inputs[3].pointer,
                inputs[3].length,
            );
            if (handle === 0) this.throwLastError('contourLevels');
            return {
                levels: this.copyF32(
                    this.exports.wc_lines_levels_ptr(handle),
                    this.exports.wc_lines_levels_len(handle),
                ),
                vertices: this.copyF32(
                    this.exports.wc_lines_vertices_ptr(handle),
                    this.exports.wc_lines_vertices_len(handle),
                ),
                pathOffsets: this.copyU32(
                    this.exports.wc_lines_path_offsets_ptr(handle),
                    this.exports.wc_lines_path_offsets_len(handle),
                ),
                pathLevelIndices: this.copyU32(
                    this.exports.wc_lines_path_levels_ptr(handle),
                    this.exports.wc_lines_path_levels_len(handle),
                ),
                pathFlags: this.copyU8(
                    this.exports.wc_lines_path_flags_ptr(handle),
                    this.exports.wc_lines_path_flags_len(handle),
                ),
                stats: this.copyU32(
                    this.exports.wc_lines_stats_ptr(handle),
                    this.exports.wc_lines_stats_len(handle),
                ),
            };
        }
        finally {
            if (handle !== 0) this.exports.wc_lines_free(handle);
            this.release(inputs);
        }
    }

    public isobands(
        values: Float32Array,
        nx: number,
        ny: number,
        xs: Float32Array | readonly number[],
        ys: Float32Array | readonly number[],
        levels: Float32Array | readonly number[],
    ): WasmPackedBands {
        const inputs = [
            this.allocate(values),
            this.allocate(xs),
            this.allocate(ys),
            this.allocate(levels),
        ];
        this.upload(inputs);
        let handle = 0;
        try {
            handle = this.exports.wc_isobands(
                inputs[0].pointer,
                inputs[0].length,
                nx,
                ny,
                inputs[1].pointer,
                inputs[1].length,
                inputs[2].pointer,
                inputs[2].length,
                inputs[3].pointer,
                inputs[3].length,
            );
            if (handle === 0) this.throwLastError('isobands');
            return {
                levels: this.copyF32(
                    this.exports.wc_bands_levels_ptr(handle),
                    this.exports.wc_bands_levels_len(handle),
                ),
                vertices: this.copyF32(
                    this.exports.wc_bands_vertices_ptr(handle),
                    this.exports.wc_bands_vertices_len(handle),
                ),
                indices: this.copyU32(
                    this.exports.wc_bands_indices_ptr(handle),
                    this.exports.wc_bands_indices_len(handle),
                ),
                triangleBandIndices: this.copyU32(
                    this.exports.wc_bands_triangle_bands_ptr(handle),
                    this.exports.wc_bands_triangle_bands_len(handle),
                ),
                stats: this.copyU32(
                    this.exports.wc_bands_stats_ptr(handle),
                    this.exports.wc_bands_stats_len(handle),
                ),
            };
        }
        finally {
            if (handle !== 0) this.exports.wc_bands_free(handle);
            this.release(inputs);
        }
    }
}

async function instantiateSource(source: WeatherContoursWasmSource): Promise<WebAssembly.Instance> {
    if (source instanceof WebAssembly.Module) {
        return WebAssembly.instantiate(source, {});
    }
    if (source instanceof ArrayBuffer) {
        const result = await WebAssembly.instantiate(source, {});
        return result instanceof WebAssembly.Instance ? result : result.instance;
    }

    const response = source instanceof Response ? source : await fetch(source);
    if (!response.ok) {
        throw new Error(`Failed to fetch weather_contours.wasm: ${response.status} ${response.statusText}`);
    }
    if ('instantiateStreaming' in WebAssembly) {
        try {
            const result = await WebAssembly.instantiateStreaming(response.clone(), {});
            return result.instance;
        }
        catch {
            // Common when a static host serves .wasm with the wrong MIME type.
        }
    }
    const result = await WebAssembly.instantiate(await response.arrayBuffer(), {});
    return result instanceof WebAssembly.Instance ? result : result.instance;
}

/** Load the dependency-free `weather_contours.wasm` module. */
export async function loadWeatherContoursWasm(
    source: WeatherContoursWasmSource,
): Promise<WeatherContoursWasm> {
    const instance = await instantiateSource(source);
    const exports = instance.exports as unknown as WeatherContoursExports;
    if (!(exports.memory instanceof WebAssembly.Memory) || typeof exports.wc_isobands !== 'function') {
        throw new Error('The supplied module is not a weather-contours WASM build.');
    }
    return new WeatherContoursWasm(exports);
}
