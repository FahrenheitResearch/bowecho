#version 300 es

in highp vec2 v_tex_coord;
out highp vec4 fragColor;

#ifndef REGULAR_LEVELS
uniform sampler2D u_band_levels;
uniform highp usampler2D u_level_directory;
#endif
uniform int u_level_count;
uniform int u_band_count;
#ifdef MIXED_LEVELS
uniform int u_levels_regular;
#endif
uniform highp float u_level_min;
uniform highp float u_level_max;
#ifndef EXPLICIT_LEVELS
uniform highp float u_level_interval;
#endif

#ifdef MASK
uniform sampler2D u_mask_sampler;
uniform int u_mask_val;
#endif

uniform highp vec4 u_line_color;
uniform highp float u_line_width;
uniform highp float u_line_opacity;
uniform int u_major_every;
uniform int u_major_offset;
uniform highp vec4 u_major_line_color;
uniform highp float u_major_line_width;
uniform highp float u_line_feather;

const int ORDINAL_DIRECTORY_SIZE = 256;

#ifdef MANUAL_BILINEAR
uniform highp vec2 u_field_size;
#endif

highp float sample_weather_field(highp vec2 tex_coord) {
#ifdef MANUAL_BILINEAR
    // R32F linear filtering is optional in WebGL 2. Four nearest samples keep
    // bilinear weather-field semantics on devices without the extension.
    highp vec2 grid_position = tex_coord * u_field_size - vec2(0.5);
    highp vec2 base = floor(grid_position);
    highp vec2 fraction = grid_position - base;
    highp vec2 maximum_index = u_field_size - vec2(1.0);
    highp vec2 index00 = clamp(base, vec2(0.0), maximum_index);
    highp vec2 index11 = clamp(base + vec2(1.0), vec2(0.0), maximum_index);
    highp vec2 uv00 = (index00 + vec2(0.5)) / u_field_size;
    highp vec2 uv10 = (vec2(index11.x, index00.y) + vec2(0.5)) / u_field_size;
    highp vec2 uv01 = (vec2(index00.x, index11.y) + vec2(0.5)) / u_field_size;
    highp vec2 uv11 = (index11 + vec2(0.5)) / u_field_size;
    highp float southwest = get_field_value(uv00);
    highp float southeast = get_field_value(uv10);
    highp float northwest = get_field_value(uv01);
    highp float northeast = get_field_value(uv11);
    return mix(
        mix(southwest, southeast, fraction.x),
        mix(northwest, northeast, fraction.x),
        fraction.y
    );
#else
    return get_field_value(tex_coord);
#endif
}

highp float boundary_value(int index) {
#ifdef REGULAR_LEVELS
    highp float offset = float(index) * u_level_interval;
    return u_level_min + offset;
#else
    return texelFetch(u_band_levels, ivec2(index, 0), 0).r;
#endif
}

int exact_upper_bound(highp float value) {
#ifdef REGULAR_LEVELS
    int low = 0;
    int high = u_level_count;
#else
    highp float normalized = clamp(
        (value - u_level_min) / (u_level_max - u_level_min),
        0.0,
        1.0
    );
    int bucket = min(
        int(floor(normalized * float(ORDINAL_DIRECTORY_SIZE))),
        ORDINAL_DIRECTORY_SIZE - 1
    );
    highp uvec2 bracket = texelFetch(u_level_directory, ivec2(bucket, 0), 0).rg;
    int low = int(bracket.r);
    int high = int(bracket.g);
#endif
    // 4096 boundaries have a 4096-wide half-open search interval. The
    // lower-tail case still needs 13 comparisons to collapse [0, 4096).
    for (int step = 0; step < 13; ++step) {
        if (low < high) {
            int middle = low + (high - low) / 2;
            if (value < boundary_value(middle)) high = middle;
            else low = middle + 1;
        }
    }
    return low;
}

#ifndef EXPLICIT_LEVELS
int certified_regular_band(highp float value) {
    int candidate = clamp(
        int(floor((value - u_level_min) / u_level_interval)),
        0,
        u_band_count - 1
    );

    // The arithmetic estimate can round across a boundary after cancellation
    // (for example, nextDown(0) - (-1) rounds to 1). Certify against exact
    // reconstructed thresholds and repair the overwhelmingly common ±1 case.
    highp float lower = boundary_value(candidate);
    if (value < lower && candidate > 0) {
        candidate -= 1;
    }
    else if (
        candidate < u_band_count - 1 &&
        value >= boundary_value(candidate + 1)
    ) {
        candidate += 1;
    }

    lower = boundary_value(candidate);
    bool lower_ok = value >= lower;
    bool upper_ok = candidate == u_band_count - 1 ||
        value < boundary_value(candidate + 1);
    if (lower_ok && upper_ok) return candidate;

    // Defensive exact fallback for exotic ranges/drivers. This is cold for
    // normal meteorological maps but preserves the float32 boundary contract.
    return clamp(exact_upper_bound(value) - 1, 0, u_band_count - 1);
}

#endif

int band_ordinal(highp float value) {
#ifdef REGULAR_LEVELS
    return certified_regular_band(value);
#else
#ifdef MIXED_LEVELS
    if (u_levels_regular != 0) return certified_regular_band(value);
#endif
    return clamp(exact_upper_bound(value) - 1, 0, u_band_count - 1);
#endif
}

int positive_mod(int value, int modulus) {
    int result = value % modulus;
    return result < 0 ? result + modulus : result;
}

void main() {
    highp float value = sample_weather_field(v_tex_coord);
    if (isnan(value) || isinf(value) || u_level_count < 2 || u_band_count < 1) discard;
#ifdef MASK
    highp float mask_value = texture(u_mask_sampler, v_tex_coord).r;
    if (int(mask_value * 255.0 + 0.5) != u_mask_val) discard;
#endif

    int band = band_ordinal(value);
    int lower_index = band;
    int upper_index = min(band + 1, u_level_count - 1);
    if (value < u_level_min) {
        lower_index = 0;
        upper_index = 0;
    }
    else if (value > u_level_max) {
        lower_index = u_level_count - 1;
        upper_index = lower_index;
    }

    highp float lower_value = boundary_value(lower_index);
    highp float upper_value = boundary_value(upper_index);
    highp float lower_distance = abs(value - lower_value);
    highp float upper_distance = abs(value - upper_value);
    int boundary_index = lower_distance <= upper_distance ? lower_index : upper_index;
    highp float nearest_value = lower_distance <= upper_distance ? lower_value : upper_value;

    bool major = u_major_every > 0 &&
        positive_mod(boundary_index - u_major_offset, u_major_every) == 0;
    highp float width = major ? u_major_line_width : u_line_width;
    highp vec4 color = major ? u_major_line_color : u_line_color;

    highp vec2 screen_gradient = vec2(dFdx(value), dFdy(value));
    highp float gradient_magnitude = length(screen_gradient);
    highp float gradient_floor = max(1.0, abs(value)) * 1.0e-12;
    if (!(gradient_magnitude > gradient_floor)) discard;

    highp float distance_pixels = abs(value - nearest_value) / gradient_magnitude;
    highp float half_width = 0.5 * width;
    highp float coverage = 1.0 - smoothstep(
        max(0.0, half_width - u_line_feather),
        half_width + u_line_feather,
        distance_pixels
    );
    highp float alpha = color.a * coverage * u_line_opacity;
    if (!(alpha > 0.0)) discard;
    fragColor = vec4(color.rgb * alpha, alpha); // premultiplied
}
