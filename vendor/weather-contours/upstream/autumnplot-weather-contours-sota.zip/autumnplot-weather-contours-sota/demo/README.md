# AutumnPlot end-to-end demo

Run this after applying the library integration to the pinned AutumnPlot checkout:

```bash
node /path/to/autumnplot-weather-contours-sota/demo/install-current-upstream-demo.mjs /path/to/autumnplot-gl
cd /path/to/autumnplot-gl
npm run start
```

Choose **WeatherContours SOTA** from AutumnPlot's existing view selector. This is not a standalone shader page: it creates an AutumnPlot `PlateCarreeGrid`, `RawScalarField`, `ColorMap`, `WeatherContours`, and `PlotLayer`, then adds that custom layer through the same MapLibre path as the existing examples.

The on-map panel records:

- map render-event interval p50/p95;
- JavaScript time spent submitting `WeatherContours.render()` p50/p95;
- `updateField()` texture-upload p50/p95;
- physical/WebGL renderer string when exposed;
- the fused/split mode selected by GPU timer-query calibration;
- hardware versus manual-bilinear float field sampling;
- the exact ordinal-directory's largest binary-search bracket.

The synthetic 721×421 field rotates through 12 precomputed weather-like frames every 250 ms for 80 updates, then stops. This keeps the demo reproducible and avoids leaving a hidden animation running after switching views.

Remove only the demo changes with:

```bash
node /path/to/autumnplot-weather-contours-sota/demo/revert-current-upstream-demo.mjs /path/to/autumnplot-gl
```
