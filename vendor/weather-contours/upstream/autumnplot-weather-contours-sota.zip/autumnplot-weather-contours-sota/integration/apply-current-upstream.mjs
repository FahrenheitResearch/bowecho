#!/usr/bin/env node
import {execFileSync} from 'node:child_process';
import {cpSync, existsSync, mkdirSync, readFileSync, rmSync, writeFileSync} from 'node:fs';
import {dirname, join, resolve} from 'node:path';
import {fileURLToPath} from 'node:url';

const EXPECTED_COMMIT = 'ee93a7278c0f38026ea61d2ce2c1d6a21893d723';
const PACKAGE_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
const force = args.includes('--force');
const positional = args.filter(arg => arg !== '--force');
const repository = resolve(positional[0] ?? process.cwd());
const backup = join(repository, '.autumnplot-weather-contours-backup');
const fillPath = join(repository, 'src', 'Fill.ts');
const indexPath = join(repository, 'src', 'index.ts');
const workerPath = join(repository, 'src', 'ContourCreator.worker.ts');
const marker = "from './WeatherContours'";

function fail(message) {
    console.error(`weather-contours integration: ${message}`);
    process.exit(1);
}

if (!existsSync(fillPath) || !existsSync(indexPath) || !existsSync(workerPath)) {
    fail(`${repository} does not look like an autumnplot-gl checkout`);
}

let head = '';
try {
    head = execFileSync('git', ['-C', repository, 'rev-parse', 'HEAD'], {encoding: 'utf8'}).trim();
}
catch {
    fail('the target must be a Git checkout');
}
if (head !== EXPECTED_COMMIT && !force) {
    fail(`expected ${EXPECTED_COMMIT}, found ${head}; inspect upstream changes or pass --force`);
}

const originalFill = readFileSync(fillPath, 'utf8');
if (originalFill.includes(marker)) {
    console.log('weather-contours integration is already applied');
    process.exit(0);
}
if (existsSync(backup)) {
    fail(`backup directory already exists: ${backup}`);
}
mkdirSync(backup, {recursive: true});
writeFileSync(join(backup, 'Fill.ts'), originalFill);
writeFileSync(join(backup, 'index.ts'), readFileSync(indexPath, 'utf8'));
writeFileSync(join(backup, 'ContourCreator.worker.ts'), readFileSync(workerPath, 'utf8'));
writeFileSync(join(backup, 'HEAD'), `${head}\n`);

try {
    mkdirSync(join(repository, 'src', 'glsl'), {recursive: true});
    cpSync(join(PACKAGE_ROOT, 'autumnplot-src', 'WeatherContours.ts'), join(repository, 'src', 'WeatherContours.ts'));
    cpSync(join(PACKAGE_ROOT, 'autumnplot-src', 'WeatherContoursWasm.ts'), join(repository, 'src', 'WeatherContoursWasm.ts'));
    cpSync(join(PACKAGE_ROOT, 'autumnplot-src', 'ContourCreator.worker.ts'), workerPath);
    for (const shader of [
        'weather_contours_vertex.glsl',
        'weather_contours_fragment.glsl',
        'weather_contour_lines_fragment.glsl',
    ]) {
        cpSync(join(PACKAGE_ROOT, 'autumnplot-src', 'glsl', shader), join(repository, 'src', 'glsl', shader));
    }
    cpSync(
        join(PACKAGE_ROOT, 'rust', 'weather-contours'),
        join(repository, 'rust', 'weather-contours'),
        {recursive: true},
    );

    let fill = originalFill;
    const importAnchor = "import { DomainBufferGrid } from './grids/DomainBuffer';";
    if (!fill.includes(importAnchor)) throw new Error('Fill.ts import anchor changed');
    fill = fill.replace(
        importAnchor,
        `${importAnchor}\nimport {WeatherContours, WeatherContourLineOptions} from './WeatherContours';`,
    );
    if (!fill.includes('interface ContourFillOptions {')) {
        throw new Error('ContourFillOptions anchor changed');
    }
    fill = fill.replace(
        'interface ContourFillOptions {',
        'interface ContourFillOptions extends WeatherContourLineOptions {',
    );
    const defaultsAnchor = "    opacity: 1,\n}";
    if (!fill.includes(defaultsAnchor)) throw new Error('contour fill defaults anchor changed');
    fill = fill.replace(
        defaultsAnchor,
        `    opacity: 1,\n` +
        `    lines: false,\n` +
        `    line_mode: 'auto',\n` +
        `    line_color: '#202020',\n` +
        `    line_width: 1,\n` +
        `    line_opacity: 1,\n` +
        `    major_every: 5,\n` +
        `    major_offset: 0,\n` +
        `    major_line_color: null,\n` +
        `    major_line_width: 1.8,\n` +
        `    line_feather: 0.75,\n}`,
    );

    const classStart = fill.indexOf('class ContourFill<');
    const exportStart = fill.indexOf('\nexport {ContourFill, Raster};', classStart);
    if (classStart < 0 || exportStart < 0) throw new Error('ContourFill class anchor changed');
    const replacement = `class ContourFill<\n` +
        `    ArrayType extends TypedArray,\n` +
        `    GridType extends DomainBufferGrid,\n` +
        `    MapType extends MapLikeType,\n` +
        `> extends WeatherContours<ArrayType, GridType, MapType> {\n` +
        `    constructor(field: ExpressionScalarField<ArrayType, GridType>, opts: ContourFillOptions) {\n` +
        `        super(field, opts);\n` +
        `    }\n\n` +
        `    public async updateField(field: ExpressionScalarField<ArrayType, GridType>, mask?: Uint8Array) {\n` +
        `        await super.updateField(field, mask);\n` +
        `    }\n` +
        `}\n`;
    fill = fill.slice(0, classStart) + replacement + fill.slice(exportStart);
    writeFileSync(fillPath, fill);

    let index = readFileSync(indexPath, 'utf8');
    const indexImportAnchor = "import { FieldContourOpts } from './ContourCreator.worker';";
    if (!index.includes(indexImportAnchor)) throw new Error('index.ts import anchor changed');
    index = index.replace(
        indexImportAnchor,
        `${indexImportAnchor}\n` +
        `import {WeatherContours, WeatherContoursOptions, WeatherContourLineOptions, WeatherContourLineMode, ` +
        `ResolvedWeatherContourLineMode, clearWeatherContourAutoTuneCache} from './WeatherContours';\n` +
        `import {WeatherContoursWasm, WeatherContoursWasmSource, WasmPackedContours, WasmPackedBands, ` +
        `loadWeatherContoursWasm} from './WeatherContoursWasm';`,
    );
    const exportAnchor = 'ContourFill, Raster, ContourFillOptions, RasterOptions,';
    if (!index.includes(exportAnchor)) throw new Error('index.ts export anchor changed');
    index = index.replace(
        exportAnchor,
        `${exportAnchor}\n` +
        `        WeatherContours, WeatherContoursOptions, WeatherContourLineOptions, WeatherContourLineMode, ` +
        `ResolvedWeatherContourLineMode, clearWeatherContourAutoTuneCache,\n` +
        `        WeatherContoursWasm, WeatherContoursWasmSource, WasmPackedContours, WasmPackedBands, ` +
        `loadWeatherContoursWasm,`,
    );
    writeFileSync(indexPath, index);
}
catch (error) {
    writeFileSync(fillPath, readFileSync(join(backup, 'Fill.ts')));
    writeFileSync(indexPath, readFileSync(join(backup, 'index.ts')));
    writeFileSync(workerPath, readFileSync(join(backup, 'ContourCreator.worker.ts')));
    rmSync(join(repository, 'src', 'WeatherContours.ts'), {force: true});
    rmSync(join(repository, 'src', 'WeatherContoursWasm.ts'), {force: true});
    rmSync(join(repository, 'rust', 'weather-contours'), {recursive: true, force: true});
    rmSync(backup, {recursive: true, force: true});
    fail(error instanceof Error ? error.message : String(error));
}

console.log(`Applied weather-contours integration to ${repository}`);
console.log(`Pinned upstream: ${EXPECTED_COMMIT}`);
console.log('Run npm ci, npm run build-npm, npm run build-dist, then build-wasm.sh for lib/dist/public.');
