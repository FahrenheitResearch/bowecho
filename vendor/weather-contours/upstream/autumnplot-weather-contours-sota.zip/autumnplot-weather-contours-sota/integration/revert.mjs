#!/usr/bin/env node
import {cpSync, existsSync, readFileSync, rmSync} from 'node:fs';
import {resolve, join} from 'node:path';

const repository = resolve(process.argv[2] ?? process.cwd());
const backup = join(repository, '.autumnplot-weather-contours-backup');
if (!existsSync(backup)) {
    console.error(`No integration backup exists at ${backup}`);
    process.exit(1);
}
cpSync(join(backup, 'Fill.ts'), join(repository, 'src', 'Fill.ts'));
cpSync(join(backup, 'index.ts'), join(repository, 'src', 'index.ts'));
cpSync(join(backup, 'ContourCreator.worker.ts'), join(repository, 'src', 'ContourCreator.worker.ts'));
for (const file of [
    'WeatherContours.ts',
    'WeatherContoursWasm.ts',
    'glsl/weather_contours_vertex.glsl',
    'glsl/weather_contours_fragment.glsl',
    'glsl/weather_contour_lines_fragment.glsl',
]) {
    rmSync(join(repository, 'src', file), {force: true});
}
rmSync(join(repository, 'rust', 'weather-contours'), {recursive: true, force: true});
const head = readFileSync(join(backup, 'HEAD'), 'utf8').trim();
rmSync(backup, {recursive: true, force: true});
console.log(`Reverted weather-contours integration (original HEAD ${head})`);
