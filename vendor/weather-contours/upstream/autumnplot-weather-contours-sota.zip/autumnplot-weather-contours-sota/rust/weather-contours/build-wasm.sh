#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_ROOT="$(cd "$ROOT/../.." && pwd)"
WASM="$ROOT/target/wasm32-unknown-unknown/release/weather_contours.wasm"

cargo build --locked --manifest-path "$ROOT/Cargo.toml" --release --target wasm32-unknown-unknown

outputs=()
if (( $# > 0 )); then
  outputs=("$@")
else
  for candidate in "$PACKAGE_ROOT/dist" "$PACKAGE_ROOT/lib" "$PACKAGE_ROOT/public"; do
    [[ -d "$candidate" ]] && outputs+=("$candidate")
  done
  if (( ${#outputs[@]} == 0 )); then
    outputs=("$PACKAGE_ROOT/dist")
  fi
fi

for output in "${outputs[@]}"; do
  mkdir -p "$output"
  cp "$WASM" "$output/weather_contours.wasm"
  printf 'Wrote %s/weather_contours.wasm\n' "$output"
done
