use std::env;
use std::hint::black_box;
use std::time::Instant;

use weather_contours::{contour_levels, isobands};

fn env_usize(name: &str, default: usize) -> usize {
    env::var(name)
        .ok()
        .and_then(|value| value.parse::<usize>().ok())
        .filter(|&value| value >= 2)
        .unwrap_or(default)
}

fn percentile(samples: &mut [f64], fraction: f64) -> f64 {
    samples.sort_by(f64::total_cmp);
    let index = ((samples.len() - 1) as f64 * fraction).round() as usize;
    samples[index]
}

fn synthetic_weather_field(nx: usize, ny: usize) -> Vec<f32> {
    let mut values = Vec::with_capacity(nx * ny);
    let nx_scale = (nx - 1) as f64;
    let ny_scale = (ny - 1) as f64;
    for j in 0..ny {
        let y = j as f64 / ny_scale;
        for i in 0..nx {
            let x = i as f64 / nx_scale;
            let synoptic = 6.0 * (2.0 * std::f64::consts::PI * x).sin()
                + 4.5 * (3.0 * std::f64::consts::PI * y).cos();
            let front = 8.0 * ((x - 0.58) * 22.0 + (y - 0.47) * 9.0).tanh();
            let low = -12.0
                * (-((x - 0.36).powi(2) / 0.008 + (y - 0.61).powi(2) / 0.018)).exp();
            let waves = 2.2 * (19.0 * x + 7.0 * y).sin() * (5.0 * y).cos();
            values.push((synoptic + front + low + waves) as f32);
        }
    }
    values
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    // Defaults are deliberately laptop-friendly. Reproduce the HRRR/HREF-sized
    // case with WC_NX=1799 WC_NY=1059 WC_ROUNDS=7 cargo run --release --example benchmark.
    let nx = env_usize("WC_NX", 600);
    let ny = env_usize("WC_NY", 400);
    let rounds = env_usize("WC_ROUNDS", 7);
    let values = synthetic_weather_field(nx, ny);
    let xs: Vec<f32> = (0..nx).map(|index| index as f32).collect();
    let ys: Vec<f32> = (0..ny).map(|index| index as f32).collect();
    let levels: Vec<f32> = (-16..=16).step_by(2).map(|value| value as f32).collect();

    let warm_lines = contour_levels(&values, nx, ny, &xs, &ys, &levels)?;
    let warm_bands = isobands(&values, nx, ny, &xs, &ys, &levels)?;
    black_box((&warm_lines, &warm_bands));

    let mut line_ms = Vec::with_capacity(rounds);
    let mut band_ms = Vec::with_capacity(rounds);
    let mut last_line_points = 0;
    let mut last_band_triangles = 0;

    for _ in 0..rounds {
        let started = Instant::now();
        let lines = contour_levels(&values, nx, ny, &xs, &ys, &levels)?;
        line_ms.push(started.elapsed().as_secs_f64() * 1_000.0);
        last_line_points = lines.point_count();
        black_box(lines);

        let started = Instant::now();
        let bands = isobands(&values, nx, ny, &xs, &ys, &levels)?;
        band_ms.push(started.elapsed().as_secs_f64() * 1_000.0);
        last_band_triangles = bands.triangle_count();
        black_box(bands);
    }

    let line_p50 = percentile(&mut line_ms, 0.50);
    let line_p95 = percentile(&mut line_ms, 0.95);
    let band_p50 = percentile(&mut band_ms, 0.50);
    let band_p95 = percentile(&mut band_ms, 0.95);

    println!("weather-contours native benchmark");
    println!("grid: {nx} x {ny}; boundaries: {}; rounds: {rounds}", levels.len());
    println!(
        "OIRT isolines: p50 {line_p50:.3} ms, p95 {line_p95:.3} ms, {last_line_points} points"
    );
    println!(
        "COBRM isobands: p50 {band_p50:.3} ms, p95 {band_p95:.3} ms, {last_band_triangles} triangles"
    );
    Ok(())
}
