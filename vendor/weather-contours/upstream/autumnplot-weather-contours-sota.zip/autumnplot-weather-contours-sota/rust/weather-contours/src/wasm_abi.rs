//! Dependency-free raw WebAssembly ABI.
//!
//! This deliberately avoids wasm-bindgen/wasm-pack. JavaScript allocates input
//! buffers in linear memory, calls one extraction function, copies packed output,
//! and frees the opaque handle.

#![allow(clippy::missing_safety_doc)]

use std::slice;
use std::sync::atomic::{AtomicU32, Ordering};

use crate::{contour_levels, isobands, PackedBands, PackedContours};

const ERROR_NONE: u32 = 0;
const ERROR_NULL_INPUT: u32 = 1;
const ERROR_CONTOUR: u32 = 2;
const ERROR_BANDS: u32 = 3;

static LAST_ERROR: AtomicU32 = AtomicU32::new(ERROR_NONE);

pub struct LinesHandle {
    output: PackedContours,
    stats: [u32; 10],
}

pub struct BandsHandle {
    output: PackedBands,
    stats: [u32; 9],
}

fn as_u32(value: usize) -> u32 {
    u32::try_from(value).unwrap_or(u32::MAX)
}

impl LinesHandle {
    fn new(output: PackedContours) -> Self {
        let stats = [
            as_u32(output.stats.grid_points),
            as_u32(output.stats.cells_total),
            as_u32(output.stats.cells_finite),
            as_u32(output.stats.cells_skipped_non_finite),
            as_u32(output.stats.level_count),
            as_u32(output.stats.edge_crossings),
            as_u32(output.stats.connected_crossings),
            as_u32(output.stats.segment_count),
            as_u32(output.stats.open_path_count),
            as_u32(output.stats.closed_path_count),
        ];
        Self { output, stats }
    }
}

impl BandsHandle {
    fn new(output: PackedBands) -> Self {
        let stats = [
            as_u32(output.stats.grid_points),
            as_u32(output.stats.cells_total),
            as_u32(output.stats.cells_finite),
            as_u32(output.stats.cells_skipped_non_finite),
            as_u32(output.stats.critical_saddle_cells),
            as_u32(output.stats.fan_triangles),
            as_u32(output.stats.band_polygons),
            as_u32(output.stats.output_vertices),
            as_u32(output.stats.output_triangles),
        ];
        Self { output, stats }
    }
}

unsafe fn input_slice<'a, T>(pointer: *const T, length: usize) -> Option<&'a [T]> {
    if length == 0 {
        return Some(&[]);
    }
    if pointer.is_null() {
        return None;
    }
    Some(unsafe { slice::from_raw_parts(pointer, length) })
}

#[no_mangle]
pub extern "C" fn wc_last_error() -> u32 {
    LAST_ERROR.load(Ordering::Relaxed)
}

#[no_mangle]
pub extern "C" fn wc_alloc_f32(length: usize) -> *mut f32 {
    // A boxed slice records exactly the length JavaScript passes back to free.
    // Using Vec::with_capacity(length) here would be unsound because a Vec may
    // receive more capacity than requested, while from_raw_parts requires the
    // allocator's exact capacity on deallocation.
    let mut buffer = vec![0.0_f32; length].into_boxed_slice();
    let pointer = buffer.as_mut_ptr();
    std::mem::forget(buffer);
    pointer
}

#[no_mangle]
pub unsafe extern "C" fn wc_free_f32(pointer: *mut f32, length: usize) {
    if pointer.is_null() {
        return;
    }
    let slice_pointer = std::ptr::slice_from_raw_parts_mut(pointer, length);
    unsafe { drop(Box::from_raw(slice_pointer)) };
}

#[no_mangle]
pub unsafe extern "C" fn wc_contour_levels(
    values_pointer: *const f32,
    values_length: usize,
    nx: usize,
    ny: usize,
    xs_pointer: *const f32,
    xs_length: usize,
    ys_pointer: *const f32,
    ys_length: usize,
    levels_pointer: *const f32,
    levels_length: usize,
) -> *mut LinesHandle {
    LAST_ERROR.store(ERROR_NONE, Ordering::Relaxed);
    let Some(values) = (unsafe { input_slice(values_pointer, values_length) }) else {
        LAST_ERROR.store(ERROR_NULL_INPUT, Ordering::Relaxed);
        return std::ptr::null_mut();
    };
    let Some(xs) = (unsafe { input_slice(xs_pointer, xs_length) }) else {
        LAST_ERROR.store(ERROR_NULL_INPUT, Ordering::Relaxed);
        return std::ptr::null_mut();
    };
    let Some(ys) = (unsafe { input_slice(ys_pointer, ys_length) }) else {
        LAST_ERROR.store(ERROR_NULL_INPUT, Ordering::Relaxed);
        return std::ptr::null_mut();
    };
    let Some(levels) = (unsafe { input_slice(levels_pointer, levels_length) }) else {
        LAST_ERROR.store(ERROR_NULL_INPUT, Ordering::Relaxed);
        return std::ptr::null_mut();
    };
    match contour_levels(values, nx, ny, xs, ys, levels) {
        Ok(output) => Box::into_raw(Box::new(LinesHandle::new(output))),
        Err(_) => {
            LAST_ERROR.store(ERROR_CONTOUR, Ordering::Relaxed);
            std::ptr::null_mut()
        }
    }
}

#[no_mangle]
pub unsafe extern "C" fn wc_isobands(
    values_pointer: *const f32,
    values_length: usize,
    nx: usize,
    ny: usize,
    xs_pointer: *const f32,
    xs_length: usize,
    ys_pointer: *const f32,
    ys_length: usize,
    levels_pointer: *const f32,
    levels_length: usize,
) -> *mut BandsHandle {
    LAST_ERROR.store(ERROR_NONE, Ordering::Relaxed);
    let Some(values) = (unsafe { input_slice(values_pointer, values_length) }) else {
        LAST_ERROR.store(ERROR_NULL_INPUT, Ordering::Relaxed);
        return std::ptr::null_mut();
    };
    let Some(xs) = (unsafe { input_slice(xs_pointer, xs_length) }) else {
        LAST_ERROR.store(ERROR_NULL_INPUT, Ordering::Relaxed);
        return std::ptr::null_mut();
    };
    let Some(ys) = (unsafe { input_slice(ys_pointer, ys_length) }) else {
        LAST_ERROR.store(ERROR_NULL_INPUT, Ordering::Relaxed);
        return std::ptr::null_mut();
    };
    let Some(levels) = (unsafe { input_slice(levels_pointer, levels_length) }) else {
        LAST_ERROR.store(ERROR_NULL_INPUT, Ordering::Relaxed);
        return std::ptr::null_mut();
    };
    match isobands(values, nx, ny, xs, ys, levels) {
        Ok(output) => Box::into_raw(Box::new(BandsHandle::new(output))),
        Err(_) => {
            LAST_ERROR.store(ERROR_BANDS, Ordering::Relaxed);
            std::ptr::null_mut()
        }
    }
}

#[no_mangle]
pub unsafe extern "C" fn wc_lines_free(handle: *mut LinesHandle) {
    if !handle.is_null() {
        unsafe { drop(Box::from_raw(handle)) };
    }
}

#[no_mangle]
pub unsafe extern "C" fn wc_bands_free(handle: *mut BandsHandle) {
    if !handle.is_null() {
        unsafe { drop(Box::from_raw(handle)) };
    }
}

// Rust has no stable identifier concatenation macro, so the small ABI surface
// remains explicit. Every accessor tolerates a null handle and returns zero.
macro_rules! ptr_len {
    ($ptr_name:ident, $len_name:ident, $handle:ty, $field:ident, $element:ty) => {
        #[no_mangle]
        pub unsafe extern "C" fn $ptr_name(handle: *const $handle) -> *const $element {
            if handle.is_null() {
                return std::ptr::null();
            }
            unsafe { (*handle).output.$field.as_ptr() }
        }
        #[no_mangle]
        pub unsafe extern "C" fn $len_name(handle: *const $handle) -> usize {
            if handle.is_null() {
                return 0;
            }
            unsafe { (*handle).output.$field.len() }
        }
    };
}

ptr_len!(wc_lines_levels_ptr, wc_lines_levels_len, LinesHandle, levels, f32);
ptr_len!(wc_lines_vertices_ptr, wc_lines_vertices_len, LinesHandle, vertices, f32);
ptr_len!(
    wc_lines_path_offsets_ptr,
    wc_lines_path_offsets_len,
    LinesHandle,
    path_offsets,
    u32
);
ptr_len!(
    wc_lines_path_levels_ptr,
    wc_lines_path_levels_len,
    LinesHandle,
    path_level_indices,
    u32
);
ptr_len!(wc_lines_path_flags_ptr, wc_lines_path_flags_len, LinesHandle, path_flags, u8);

ptr_len!(wc_bands_levels_ptr, wc_bands_levels_len, BandsHandle, levels, f32);
ptr_len!(wc_bands_vertices_ptr, wc_bands_vertices_len, BandsHandle, vertices, f32);
ptr_len!(wc_bands_indices_ptr, wc_bands_indices_len, BandsHandle, indices, u32);
ptr_len!(
    wc_bands_triangle_bands_ptr,
    wc_bands_triangle_bands_len,
    BandsHandle,
    triangle_band_indices,
    u32
);

#[no_mangle]
pub unsafe extern "C" fn wc_lines_stats_ptr(handle: *const LinesHandle) -> *const u32 {
    if handle.is_null() {
        return std::ptr::null();
    }
    unsafe { (*handle).stats.as_ptr() }
}

#[no_mangle]
pub unsafe extern "C" fn wc_lines_stats_len(handle: *const LinesHandle) -> usize {
    if handle.is_null() { 0 } else { 10 }
}

#[no_mangle]
pub unsafe extern "C" fn wc_bands_stats_ptr(handle: *const BandsHandle) -> *const u32 {
    if handle.is_null() {
        return std::ptr::null();
    }
    unsafe { (*handle).stats.as_ptr() }
}

#[no_mangle]
pub unsafe extern "C" fn wc_bands_stats_len(handle: *const BandsHandle) -> usize {
    if handle.is_null() { 0 } else { 9 }
}
