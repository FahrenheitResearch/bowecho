#!/usr/bin/env python3
"""Compile all production shader variants in Chromium WebGL 2.

Each variant is tested twice: once through the driver's GLSL preprocessor and
once after emulating autumn-wgl's small #ifdef preprocessor. The latter also
checks that every declared uniform is active, because WGLProgram treats a null
uniform location as an integration failure.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import tempfile
import time
import urllib.request
from pathlib import Path

import websocket

ROOT = Path(__file__).resolve().parents[1]
PORT = 19224
DISPLAY = ':98'


def inject_after_version(source: str, code: str) -> str:
    first, rest = source.split('\n', 1)
    return f"{first}\n{code}\n{rest}"


def autumn_preprocess(source: str, definitions: list[str]) -> str:
    defs = list(definitions)
    stack: list[tuple[str, bool]] = []
    output: list[str] = []
    for line in source.splitlines():
        match = re.search(r'#define\s+([\w\d_]+)', line, re.I)
        if match:
            defs.append(match.group(1))
        match = re.search(r'#ifdef\s+([\w\d_]+)', line, re.I)
        if match:
            stack.append((match.group(1), True))
            output.append('')
            continue
        match = re.search(r'#ifndef\s+([\w\d_]+)', line, re.I)
        if match:
            stack.append((match.group(1), False))
            output.append('')
            continue
        if re.search(r'#else\b', line, re.I):
            if not stack:
                raise RuntimeError('orphan #else')
            name, truth = stack.pop()
            stack.append((name, not truth))
            output.append('')
            continue
        if re.search(r'#endif\b', line, re.I):
            if not stack:
                raise RuntimeError('orphan #endif')
            stack.pop()
            output.append('')
            continue
        keep = all((name in defs) == truth for name, truth in stack)
        output.append(line if keep else '')
    if stack:
        raise RuntimeError('unterminated #ifdef/#ifndef')
    return '\n'.join(output)


def evaluate(ws: websocket.WebSocket, expression: str, request_id: int = 1) -> object:
    ws.send(json.dumps({
        'id': request_id,
        'method': 'Runtime.evaluate',
        'params': {
            'expression': expression,
            'returnByValue': True,
            'awaitPromise': True,
            'timeout': 30_000,
        },
    }))
    while True:
        message = json.loads(ws.recv())
        if message.get('id') != request_id:
            continue
        result = message.get('result', {})
        if 'exceptionDetails' in result:
            raise RuntimeError(json.dumps(result['exceptionDetails'], indent=2))
        return result['result'].get('value')


def main() -> None:
    chromium_path = next(
        (shutil.which(name) for name in ('chromium', 'chromium-browser', 'google-chrome') if shutil.which(name)),
        None,
    )
    xvfb_path = shutil.which('Xvfb')
    if chromium_path is None or xvfb_path is None:
        raise RuntimeError('Chromium and Xvfb are required for shader validation')

    vertex = inject_after_version(
        (ROOT / 'autumnplot-src/glsl/weather_contours_vertex.glsl').read_text(),
        'uniform mat4 u_projection_matrix;\n'
        'vec4 projectTile(vec2 p) { return u_projection_matrix * vec4(p, 0.0, 1.0); }',
    )
    sampler_code = (
        'uniform sampler2D u_field;\n'
        'highp float get_field_value(highp vec2 p) { return texture(u_field, p).r; }'
    )
    fill_fragment = inject_after_version(
        (ROOT / 'autumnplot-src/glsl/weather_contours_fragment.glsl').read_text(),
        sampler_code,
    )
    line_fragment = inject_after_version(
        (ROOT / 'autumnplot-src/glsl/weather_contour_lines_fragment.glsl').read_text(),
        sampler_code,
    )

    variants: list[dict[str, object]] = []
    base_variants = [
        ('fill', fill_fragment, []),
        ('fill_masked', fill_fragment, ['MASK']),
        ('fused_fill_lines', fill_fragment, ['CONTOUR_LINES']),
        ('fused_fill_lines_masked', fill_fragment, ['MASK', 'CONTOUR_LINES']),
        ('split_lines', line_fragment, []),
        ('split_lines_masked', line_fragment, ['MASK']),
    ]
    for layout_define in ('REGULAR_LEVELS', 'EXPLICIT_LEVELS', 'MIXED_LEVELS'):
        layout_name = layout_define.removesuffix('_LEVELS').lower()
        for sampling_name, sampling_definitions in (
            ('hardware', []),
            ('manual_bilinear', ['MANUAL_BILINEAR']),
        ):
            for name, fragment, definitions in base_variants:
                defs = [layout_define, *sampling_definitions, *definitions]
                variants.append({
                    'name': f'{layout_name}_{sampling_name}_{name}',
                    'definitions': defs,
                    'vertex': vertex,
                    'fragment': fragment,
                    'pre_vertex': autumn_preprocess(vertex, defs),
                    'pre_fragment': autumn_preprocess(fragment, defs),
                })

    expression = f'''(() => {{
      const variants = {json.dumps(variants)};
      function addDefines(src, defs) {{
        const lines = src.split('\\n');
        lines.splice(1, 0, ...defs.map(d => '#define ' + d));
        return lines.join('\\n');
      }}
      function compile(gl, type, source, name) {{
        const shader = gl.createShader(type);
        gl.shaderSource(shader, source);
        gl.compileShader(shader);
        if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {{
          throw new Error(name + ': ' + gl.getShaderInfoLog(shader) + '\\n' + source);
        }}
        return shader;
      }}
      function declaredUniforms(source) {{
        const clean = source.replace(/\\/\\*[\\s\\S]*?\\*\\//g, '').replace(/\\/\\/.*$/gm, '');
        const names = [];
        const regex = /uniform\\s+(?:lowp\\s+|mediump\\s+|highp\\s+)?[\\w]+\\s+([\\w_]+)(?:\\s*\\[[^\\]]+\\])?\\s*;/g;
        for (const match of clean.matchAll(regex)) names.push(match[1]);
        return names;
      }}
      function build(gl, vertexSource, fragmentSource, name, checkUniforms) {{
        const program = gl.createProgram();
        gl.attachShader(program, compile(gl, gl.VERTEX_SHADER, vertexSource, name + '/vertex'));
        gl.attachShader(program, compile(gl, gl.FRAGMENT_SHADER, fragmentSource, name + '/fragment'));
        gl.linkProgram(program);
        if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {{
          throw new Error(name + ': ' + gl.getProgramInfoLog(program));
        }}
        if (checkUniforms) {{
          const uniforms = [...new Set([...declaredUniforms(vertexSource), ...declaredUniforms(fragmentSource)])];
          for (const uniform of uniforms) {{
            if (gl.getUniformLocation(program, uniform) === null) {{
              throw new Error(name + ': declared uniform optimized away: ' + uniform);
            }}
          }}
        }}
      }}
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl2');
      if (!gl) throw new Error('WebGL2 unavailable');
      const compiled = [];
      for (const variant of variants) {{
        build(
          gl,
          addDefines(variant.vertex, variant.definitions),
          addDefines(variant.fragment, variant.definitions),
          variant.name + '/driver-preprocessor',
          false
        );
        build(
          gl,
          variant.pre_vertex,
          variant.pre_fragment,
          variant.name + '/autumn-wgl-preprocessor',
          true
        );
        compiled.push(variant.name);
      }}
      return {{
        compiled,
        version: gl.getParameter(gl.VERSION),
        renderer: gl.getParameter(gl.RENDERER),
      }};
    }})()'''

    xvfb = chromium = None
    profile: str | None = None
    try:
        xvfb = subprocess.Popen(
            [xvfb_path, DISPLAY, '-screen', '0', '1280x720x24'],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        time.sleep(0.4)
        profile = tempfile.mkdtemp(prefix='weather-contours-chromium-')
        environment = os.environ.copy()
        environment['DISPLAY'] = DISPLAY
        chromium = subprocess.Popen(
            [
                chromium_path,
                '--no-sandbox',
                '--disable-dev-shm-usage',
                '--use-angle=swiftshader',
                '--enable-unsafe-swiftshader',
                f'--remote-debugging-port={PORT}',
                '--remote-allow-origins=*',
                f'--user-data-dir={profile}',
                'about:blank',
            ],
            env=environment,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        tabs = None
        for _ in range(100):
            try:
                with urllib.request.urlopen(f'http://127.0.0.1:{PORT}/json', timeout=0.2) as response:
                    tabs = json.load(response)
                if tabs:
                    break
            except Exception:
                pass
            time.sleep(0.1)
        if not tabs:
            raise RuntimeError('Chromium DevTools endpoint did not start')
        tab = next(tab for tab in tabs if tab.get('type') == 'page')
        ws = websocket.create_connection(
            tab['webSocketDebuggerUrl'],
            timeout=35,
            origin=f'http://127.0.0.1:{PORT}',
        )
        try:
            result = evaluate(ws, expression)
        finally:
            ws.close()
        expected = [variant['name'] for variant in variants]
        if not isinstance(result, dict) or result.get('compiled') != expected:
            raise RuntimeError(f'unexpected shader result: {result!r}')
        print(
            'Real Chromium WebGL2 compile/link + autumn-wgl uniform check passed '
            f"({len(expected)} variants × 2 paths; {result['version']}; {result['renderer']})"
        )
    finally:
        for process in (chromium, xvfb):
            if process is not None and process.poll() is None:
                process.terminate()
        time.sleep(0.2)
        for process in (chromium, xvfb):
            if process is not None and process.poll() is None:
                process.kill()
        if profile is not None:
            shutil.rmtree(profile, ignore_errors=True)


if __name__ == '__main__':
    main()
