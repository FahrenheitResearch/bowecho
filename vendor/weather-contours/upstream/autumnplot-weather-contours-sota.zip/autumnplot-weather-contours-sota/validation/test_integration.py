#!/usr/bin/env python3
from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

FILL = r'''import { PlotComponent, getGLFormatTypeAlignment } from './PlotComponent';
import { ColorMap, ColorMapGPUInterface} from './Colormap';
import { WGLBuffer, WGLTexture } from 'autumn-wgl';
import { ExpressionScalarField } from './RawField';
import { MapLikeType } from './Map';
import { RenderMethodArg, TypedArray, WebGLAnyRenderingContext, getRendererData } from './AutumnTypes';
import { applySamplerCodeScalar, normalizeOptions } from './utils';
import { ShaderProgramManager } from './ShaderManager';
import { DomainBufferGrid } from './grids/DomainBuffer';
interface ContourFillOptions {
    cmap: ColorMap | ColorMap[];
    cmap_mask?: Uint8Array | null;
    opacity?: number;
}
const contour_fill_opt_defaults: Required<ContourFillOptions> = {
    cmap: [] as unknown as ColorMap[],
    cmap_mask: null,
    opacity: 1,
}
interface RasterOptions { cmap: ColorMap | ColorMap[]; cmap_mask?: Uint8Array | null; opacity?: number; }
class PlotComponentFill<ArrayType extends TypedArray, GridType extends DomainBufferGrid, MapType extends MapLikeType> {}
class Raster<ArrayType extends TypedArray, GridType extends DomainBufferGrid, MapType extends MapLikeType> extends PlotComponentFill<ArrayType, GridType, MapType> {}
class ContourFill<ArrayType extends TypedArray, GridType extends DomainBufferGrid, MapType extends MapLikeType> extends PlotComponentFill<ArrayType, GridType, MapType> {
    constructor(field: ExpressionScalarField<ArrayType, GridType>, opts: ContourFillOptions) { super(); }
    public async updateField(field: ExpressionScalarField<ArrayType, GridType>, mask?: Uint8Array) {}
    public async onAdd(map: MapType, gl: WebGLAnyRenderingContext) {}
    public render(gl: WebGLAnyRenderingContext, matrix: number[] | Float32Array) {}
}
export {ContourFill, Raster};
export type {ContourFillOptions, RasterOptions};
'''


WORKER = r'''import * as Comlink from 'comlink';
interface FieldContourOpts { interval?: number; levels?: number[]; quad_as_tri?: boolean; }
async function contourCreator() { return {}; }
async function init() {}
const ep_interface = {contourCreator, init};
Comlink.expose(ep_interface);
type ContourCreatorWorker = typeof ep_interface;
export type {ContourCreatorWorker, FieldContourOpts};
'''

INDEX = r'''import {ContourFill, Raster, ContourFillOptions, RasterOptions} from "./Fill";
import { FieldContourOpts } from './ContourCreator.worker';
export {ContourFill, Raster, ContourFillOptions, RasterOptions,
        FieldContourOpts};
'''


def run(*args: str, cwd: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(args, cwd=cwd, text=True, capture_output=True, check=True)


def main() -> None:
    with tempfile.TemporaryDirectory(prefix='autumnplot-integration-') as directory:
        repo = Path(directory)
        (repo / 'src').mkdir()
        (repo / 'src' / 'Fill.ts').write_text(FILL)
        (repo / 'src' / 'index.ts').write_text(INDEX)
        (repo / 'src' / 'ContourCreator.worker.ts').write_text(WORKER)
        run('git', 'init', '-q', cwd=repo)
        run('git', 'config', 'user.email', 'validation@example.invalid', cwd=repo)
        run('git', 'config', 'user.name', 'Validation', cwd=repo)
        run('git', 'add', '.', cwd=repo)
        run('git', 'commit', '-qm', 'fixture', cwd=repo)
        before_fill = (repo / 'src' / 'Fill.ts').read_bytes()
        before_index = (repo / 'src' / 'index.ts').read_bytes()
        before_worker = (repo / 'src' / 'ContourCreator.worker.ts').read_bytes()

        result = run(
            'node', str(ROOT / 'integration' / 'apply-current-upstream.mjs'),
            str(repo), '--force', cwd=repo,
        )
        assert 'Applied weather-contours integration' in result.stdout
        fill = (repo / 'src' / 'Fill.ts').read_text()
        index = (repo / 'src' / 'index.ts').read_text()
        assert 'extends WeatherContours<' in fill
        assert 'extends WeatherContourLineOptions' in fill
        assert 'WeatherContoursWasm' in index
        worker = (repo / 'src' / 'ContourCreator.worker.ts').read_text()
        assert 'loadWeatherContoursWasm' in worker
        assert 'OIRT worker' in worker
        assert (repo / 'rust' / 'weather-contours' / 'Cargo.toml').exists()

        again = run(
            'node', str(ROOT / 'integration' / 'apply-current-upstream.mjs'),
            str(repo), '--force', cwd=repo,
        )
        assert 'already applied' in again.stdout

        run('node', str(ROOT / 'integration' / 'revert.mjs'), str(repo), cwd=repo)
        assert (repo / 'src' / 'Fill.ts').read_bytes() == before_fill
        assert (repo / 'src' / 'index.ts').read_bytes() == before_index
        assert (repo / 'src' / 'ContourCreator.worker.ts').read_bytes() == before_worker
        assert not (repo / 'src' / 'WeatherContours.ts').exists()
    print('Pinned integration apply/idempotence/revert test passed')


if __name__ == '__main__':
    main()
