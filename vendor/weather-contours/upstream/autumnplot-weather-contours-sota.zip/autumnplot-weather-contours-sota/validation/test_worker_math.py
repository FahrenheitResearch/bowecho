#!/usr/bin/env python3
"""Reference checks for the OIRT compatibility worker.

The TypeScript worker is compiled separately by typecheck_ts.sh. This test
exhaustively checks the binary16 widening formula and property-tests the two
nontrivial compatibility transforms: regular-level generation and packed-path
unpacking/closure.
"""
from __future__ import annotations

import math
import random
import struct
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKER = ROOT / "autumnplot-src" / "ContourCreator.worker.ts"
MAX_LEVELS = 65_536


def f32(value: float) -> float:
    return struct.unpack("<f", struct.pack("<f", value))[0]


def f32_bits(value: float) -> int:
    return struct.unpack("<I", struct.pack("<f", value))[0]


def worker_half_bits_to_float_bits(value: int) -> int:
    sign = (value & 0x8000) << 16
    exponent = (value >> 10) & 0x1F
    mantissa = value & 0x03FF
    if exponent == 0:
        if mantissa == 0:
            return sign
        exponent = 1
        while (mantissa & 0x0400) == 0:
            mantissa <<= 1
            exponent -= 1
        mantissa &= 0x03FF
        return (sign | ((exponent + 112) << 23) | (mantissa << 13)) & 0xFFFFFFFF
    if exponent == 0x1F:
        return (sign | 0x7F800000 | (mantissa << 13)) & 0xFFFFFFFF
    return (sign | ((exponent + 112) << 23) | (mantissa << 13)) & 0xFFFFFFFF


def validate_half_widening() -> int:
    nan_count = 0
    for bits16 in range(1 << 16):
        actual = worker_half_bits_to_float_bits(bits16)
        half = struct.unpack("<e", struct.pack("<H", bits16))[0]
        exponent = (bits16 >> 10) & 0x1F
        mantissa = bits16 & 0x03FF
        if exponent == 0x1F and mantissa != 0:
            nan_count += 1
            assert ((actual >> 31) & 1) == ((bits16 >> 15) & 1)
            assert ((actual >> 23) & 0xFF) == 0xFF
            assert actual & 0x7FFFFF
            # Widening should preserve all ten binary16 payload bits.
            assert (actual & 0x7FFFFF) == mantissa << 13
        else:
            expected = f32_bits(half)
            assert actual == expected, (hex(bits16), hex(actual), hex(expected), half)
    return nan_count


def interval_levels(values: list[float], interval: float, anchor: float = 0.0) -> list[float]:
    if not math.isfinite(interval) or interval <= 0.0:
        raise ValueError
    finite = [value for value in values if math.isfinite(value)]
    if not finite:
        return []
    first = math.ceil((min(finite) - anchor) / interval)
    last = math.floor((max(finite) - anchor) / interval)
    if first > last:
        return []
    count = last - first + 1
    if count > MAX_LEVELS:
        raise OverflowError
    return [f32(anchor + (first + index) * interval) for index in range(count)]


def validate_interval_levels() -> int:
    rng = random.Random(0xC07A0F)
    cases = 0
    assert interval_levels([math.nan, math.inf, -math.inf], 1.0) == []
    for _ in range(20_000):
        interval = 10.0 ** rng.uniform(-3.0, 3.0)
        anchor = rng.uniform(-1000.0, 1000.0)
        base = rng.uniform(-10_000.0, 10_000.0)
        span = interval * rng.uniform(0.0, 100.0)
        values = [
            f32(base - span),
            f32(base + span),
            f32(base + rng.uniform(-span, span)),
            math.nan,
        ]
        levels = interval_levels(values, interval, anchor)
        finite = [value for value in values if math.isfinite(value)]
        if levels:
            first_index = math.ceil((min(finite) - anchor) / interval)
            assert levels[0] == f32(anchor + first_index * interval)
            assert all(math.isfinite(level) for level in levels)
            assert len(levels) <= MAX_LEVELS
            for index, level in enumerate(levels):
                assert level == f32(anchor + (first_index + index) * interval)
        cases += 1

    try:
        interval_levels([0.0, float(MAX_LEVELS + 10)], 1.0)
    except OverflowError:
        pass
    else:
        raise AssertionError("worker level-count guard did not trigger")
    return cases


def unpack_reference(
    levels: list[float],
    vertices: list[float],
    offsets: list[int],
    path_levels: list[int],
    flags: list[int],
) -> dict[float, list[list[tuple[float, float]]]]:
    output: dict[float, list[list[tuple[float, float]]]] = {}
    for path, level_index in enumerate(path_levels):
        begin, end = offsets[path], offsets[path + 1]
        points = [(vertices[2 * point], vertices[2 * point + 1]) for point in range(begin, end)]
        if flags[path] & 1 and end > begin:
            points.append(points[0])
        output.setdefault(levels[level_index], []).append(points)
    return output


def validate_unpacking() -> int:
    rng = random.Random(0x01A7)
    paths_checked = 0
    for _ in range(5_000):
        levels = [f32(-20.0 + index * 2.5) for index in range(rng.randint(1, 20))]
        path_count = rng.randint(0, 30)
        offsets = [0]
        vertices: list[float] = []
        path_levels: list[int] = []
        flags: list[int] = []
        original: list[list[tuple[float, float]]] = []
        for _path in range(path_count):
            count = rng.randint(2, 20)
            points = [
                (f32(rng.uniform(-180.0, 180.0)), f32(rng.uniform(-90.0, 90.0)))
                for _ in range(count)
            ]
            original.append(points)
            for x, y in points:
                vertices.extend((x, y))
            offsets.append(offsets[-1] + count)
            path_levels.append(rng.randrange(len(levels)))
            flags.append(rng.randrange(2))

        unpacked = unpack_reference(levels, vertices, offsets, path_levels, flags)
        occurrence: dict[float, int] = {}
        for path in range(path_count):
            level = levels[path_levels[path]]
            index = occurrence.get(level, 0)
            occurrence[level] = index + 1
            points = unpacked[level][index]
            expected = original[path]
            if flags[path] & 1:
                assert points[:-1] == expected
                assert points[-1] == expected[0]
            else:
                assert points == expected
            paths_checked += 1
    return paths_checked


def validate_source_contract() -> None:
    source = WORKER.read_text()
    required = [
        "loadWeatherContoursWasm",
        "geometry.contourLevels(",
        "new URL('weather_contours.wasm', self.location.href)",
        "new Float32Array(1 << 16)",
        "halfBitsToFloatBits",
        "flags[path] & 1",
        "bilinear asymptotic decider",
        "MAX_COMPATIBILITY_LEVELS = 65_536",
        "values.length !== nx * ny",
    ]
    for needle in required:
        assert needle in source, needle
    assert "./WasmInterface" not in source
    assert "makeContoursFloat32" not in source


def main() -> None:
    validate_source_contract()
    nan_count = validate_half_widening()
    interval_cases = validate_interval_levels()
    path_count = validate_unpacking()
    print(
        "OIRT compatibility-worker reference validation passed "
        f"(65,536 binary16 patterns, {nan_count} NaNs, "
        f"{interval_cases:,} interval cases, {path_count:,} packed paths)"
    )


if __name__ == "__main__":
    main()
